Command line used to find this crash:

/home/angr/.virtualenvs/angr/bin/afl-unix/afl-fuzz -i - -o ./work/aeg_data/b64_encode_1/sync -m 8G -Q -M fuzzer-master -- /usr/downloads/test/testcase/robo_change/work/binary/b64_encode_1

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 8.00 GB.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
me a mail at <lcamtuf@coredump.cx> once the issues are fixed - I'd love to
add your finds to the gallery at:

  http://lcamtuf.coredump.cx/afl/

Thanks :-)
